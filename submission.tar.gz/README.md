# VerstappenSimulator
 ![startScreen](https://github.com/BANANAPEEL202/VerstappenSimulator/assets/67805049/237a13f5-33d1-4eef-a4a9-7702754159b2)

This is a Max Verstappen Simulator on the Nintendo Game Boy Advanced. Overtake 4 opponents to finish in P1. 

# Controls
**Movement** - Up, down, left, right arrows <br />
**Reset Game** - Select key (delete) <br />
**Start Game** - Start key (eneter) <br />

# Gameplay
https://github.com/BANANAPEEL202/VerstappenSimulator/assets/67805049/96fed9f9-1354-4c51-b8ef-2975013ccc8c


