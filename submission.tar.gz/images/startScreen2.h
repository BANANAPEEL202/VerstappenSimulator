/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 startScreen2 startScreen2.png 
 * Time-stamp: Saturday 03/30/2024, 23:42:32
 * 
 * Image Information
 * -----------------
 * startScreen2.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STARTSCREEN2_H
#define STARTSCREEN2_H

extern const unsigned short startScreen2[38400];
#define STARTSCREEN2_SIZE 76800
#define STARTSCREEN2_LENGTH 38400
#define STARTSCREEN2_WIDTH 240
#define STARTSCREEN2_HEIGHT 160

#endif

