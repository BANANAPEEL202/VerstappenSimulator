/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 rightCurb rightCurb.png 
 * Time-stamp: Friday 03/29/2024, 17:07:23
 * 
 * Image Information
 * -----------------
 * rightCurb.png 16@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RIGHTCURB_H
#define RIGHTCURB_H

extern const unsigned short rightCurb[2560];
#define RIGHTCURB_SIZE 5120
#define RIGHTCURB_LENGTH 2560
#define RIGHTCURB_WIDTH 16
#define RIGHTCURB_HEIGHT 160

#endif

