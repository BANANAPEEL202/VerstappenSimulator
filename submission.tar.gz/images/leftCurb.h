/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 leftCurb leftCurb.png 
 * Time-stamp: Friday 03/29/2024, 15:06:08
 * 
 * Image Information
 * -----------------
 * leftCurb.png 29@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LEFTCURB_H
#define LEFTCURB_H

extern const unsigned short leftCurb[4640];
#define LEFTCURB_SIZE 9280
#define LEFTCURB_LENGTH 4640
#define LEFTCURB_WIDTH 29
#define LEFTCURB_HEIGHT 160

#endif

