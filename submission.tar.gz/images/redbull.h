/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 redbull redbull.png 
 * Time-stamp: Saturday 03/30/2024, 05:41:12
 * 
 * Image Information
 * -----------------
 * redbull.png 21@55
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef REDBULL_H
#define REDBULL_H

extern const unsigned short redbull[1155];
#define REDBULL_SIZE 2310
#define REDBULL_LENGTH 1155
#define REDBULL_WIDTH 21
#define REDBULL_HEIGHT 55

#endif

