/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 redbullLeft redbullLeft.png 
 * Time-stamp: Sunday 03/31/2024, 00:16:20
 * 
 * Image Information
 * -----------------
 * redbullLeft.png 21@55
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef REDBULLLEFT_H
#define REDBULLLEFT_H

extern const unsigned short redbullLeft[1155];
#define REDBULLLEFT_SIZE 2310
#define REDBULLLEFT_LENGTH 1155
#define REDBULLLEFT_WIDTH 21
#define REDBULLLEFT_HEIGHT 55

#endif

