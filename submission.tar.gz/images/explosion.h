/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 explosion explosion.png 
 * Time-stamp: Friday 03/29/2024, 21:13:58
 * 
 * Image Information
 * -----------------
 * explosion.png 120@120
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef EXPLOSION_H
#define EXPLOSION_H

extern const unsigned short explosion[14400];
#define EXPLOSION_SIZE 28800
#define EXPLOSION_LENGTH 14400
#define EXPLOSION_WIDTH 120
#define EXPLOSION_HEIGHT 120

#endif

