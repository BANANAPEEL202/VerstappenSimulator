/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 mercedes mercedes.png 
 * Time-stamp: Saturday 03/30/2024, 05:41:38
 * 
 * Image Information
 * -----------------
 * mercedes.png 21@55
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MERCEDES_H
#define MERCEDES_H

extern const unsigned short mercedes[1155];
#define MERCEDES_SIZE 2310
#define MERCEDES_LENGTH 1155
#define MERCEDES_WIDTH 21
#define MERCEDES_HEIGHT 55

#endif

