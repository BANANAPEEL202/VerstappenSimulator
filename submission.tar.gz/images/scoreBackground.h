/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 scoreBackground scoreBackground.png 
 * Time-stamp: Saturday 03/30/2024, 21:07:40
 * 
 * Image Information
 * -----------------
 * scoreBackground.png 55@77
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SCOREBACKGROUND_H
#define SCOREBACKGROUND_H

extern const unsigned short scoreBackground[4235];
#define SCOREBACKGROUND_SIZE 8470
#define SCOREBACKGROUND_LENGTH 4235
#define SCOREBACKGROUND_WIDTH 55
#define SCOREBACKGROUND_HEIGHT 77

#endif

