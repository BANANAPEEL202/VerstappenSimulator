/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 mclaren mclaren.png 
 * Time-stamp: Saturday 03/30/2024, 05:41:44
 * 
 * Image Information
 * -----------------
 * mclaren.png 21@55
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MCLAREN_H
#define MCLAREN_H

extern const unsigned short mclaren[1155];
#define MCLAREN_SIZE 2310
#define MCLAREN_LENGTH 1155
#define MCLAREN_WIDTH 21
#define MCLAREN_HEIGHT 55

#endif

