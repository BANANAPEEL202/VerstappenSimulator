/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 redbullRight redbullRight.png 
 * Time-stamp: Sunday 03/31/2024, 00:16:29
 * 
 * Image Information
 * -----------------
 * redbullRight.png 21@55
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef REDBULLRIGHT_H
#define REDBULLRIGHT_H

extern const unsigned short redbullRight[1155];
#define REDBULLRIGHT_SIZE 2310
#define REDBULLRIGHT_LENGTH 1155
#define REDBULLRIGHT_WIDTH 21
#define REDBULLRIGHT_HEIGHT 55

#endif

