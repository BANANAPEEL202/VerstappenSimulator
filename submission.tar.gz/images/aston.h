/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 aston aston.png 
 * Time-stamp: Saturday 03/30/2024, 19:50:27
 * 
 * Image Information
 * -----------------
 * aston.png 21@55
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ASTON_H
#define ASTON_H

extern const unsigned short aston[1155];
#define ASTON_SIZE 2310
#define ASTON_LENGTH 1155
#define ASTON_WIDTH 21
#define ASTON_HEIGHT 55

#endif

