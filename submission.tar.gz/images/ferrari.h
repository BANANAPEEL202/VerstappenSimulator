/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 ferrari ferrari.png 
 * Time-stamp: Saturday 03/30/2024, 05:41:53
 * 
 * Image Information
 * -----------------
 * ferrari.png 21@55
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FERRARI_H
#define FERRARI_H

extern const unsigned short ferrari[1155];
#define FERRARI_SIZE 2310
#define FERRARI_LENGTH 1155
#define FERRARI_WIDTH 21
#define FERRARI_HEIGHT 55

#endif

